<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>

<body>
  <h1>Ubah Tugas</h1>
  <form action="?url=simpanUbah" method="post">
    <input type="hidden" name="id" value="<?= $data['id'] ?>">
    <input type="hidden" name="tanggal" value="<?= $data['tanggal'] ?>">
    <table>
      <tr>
        <td>Task</td>
        <td>:</td>
        <td><textarea name="task" id="" cols="30" rows="10"><?= $data['task']; ?></textarea></td>
      </tr>
      <tr>
        <td>Prioriti</td>
        <td>:</td>
        <td>
          <select name="prioriti" id="">
            <?php
            if ($data['prioriti'] == 1) {
              echo "<option value=\"1\" selected>Low</option>";
            } else {
              echo "<option value=\"1\">Low</option>";
            }
            if ($data['prioriti'] == 2) {
              echo "<option value=\"2\" selected>Medium</option>";
            } else {
              echo "<option value=\"2\">Medium</option>";
            }
            if ($data['prioriti'] == 3) {
              echo "<option value=\"3\" selected>High</option>";
            } else {
              echo "<option value=\"3\">High</option>";
            }
            ?>
          </select>
        </td>
      </tr>
      <tr>
        <td>Status</td>
        <td>:</td>
        <td>
          <select name="status" id="">
            <?php
            if ($data['status'] == 0) {
              echo "<option value=\"0\" selected>Belum Selesai</option>";
            } else {
              echo "<option value=\"0\" >Belum Selesai</option>";
            }
            if ($data['status'] == 1) {
              echo "<option value=\"1\" selected>Selesai</option>";
            } else {
              echo "<option value=\"1\" >Selesai</option>";
            }
            ?>
          </select>
        </td>
      </tr>
      <tr>
        <td><input type="submit" value="Simpan"></td>
      </tr>
    </table>

  </form>
</body>

</html>