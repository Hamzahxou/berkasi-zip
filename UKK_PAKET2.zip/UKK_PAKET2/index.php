<?php

//baca url
$url = $_GET['url'] ?? "";

//cek url mau kemana 
switch ($url) {
    //tampilkan form tambah data V_tambah
  case 'tambahdata':
    include "V_Tambah.php";
    break;

  case 'simpanBaru':
    //menerima kiriman data dari V_tambah
    $task = $_POST['task'];
    $prioriti = $_POST['prioriti'];
    $tanggal = $_POST['tanggal'];
    $status = "0";

    //ambil objek tugas 
    include "Tugas.php";
    //inisialisasi objek
    $tugas = new Tugas;

    //panggil method tambah data
    $tugas->tambahData($task, $prioriti, $tanggal, $status);
    break;

    //hapus data
  case "hapus":
    $id = $_GET['id'];
    //ambil objek tugas 
    include "Tugas.php";
    //inisialisasi objek
    $tugas = new Tugas;

    $tugas->hapusData($id);
    break;

    //untuk menampilkan form ubah V_ubah
  case "edit":
    $id = $_GET['id'];
    //ambil objek tugas 
    include "Tugas.php";
    //inisialisasi objek
    $tugas = new Tugas;

    $data = $tugas->tampilUbah($id);
    include "V_Ubah.php";
    break;

    //untuk simpan data setelah di ubah
  case "simpanUbah":
    $id = $_POST['id'];
    $task = $_POST['task'];
    $prioriti = $_POST['prioriti'];
    $tanggal = $_POST['tanggal'];
    $status = $_POST['status'];

    //ambil objek tugas 
    include "Tugas.php";
    //inisialisasi objek
    $tugas = new Tugas;

    $tugas->simpanUbah($id, $task, $prioriti, $tanggal, $status);
    break;

    //jika tidak ada request tampilkan halaman v_tugas
  default:
    include "V_Tugas.php";
    break;
}
