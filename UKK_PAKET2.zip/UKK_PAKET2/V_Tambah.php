<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>

<body>
  <h1>Tambah Tugas</h1>
  <form action="?url=simpanBaru" method="post">
    <table>
      <tr>
        <td>Task</td>
        <td>:</td>
        <td><textarea name="task" id="" cols="30" rows="10"></textarea></td>
      </tr>
      <tr>
        <td>Prioriti</td>
        <td>:</td>
        <td>
          <select name="prioriti" id="">
            <option value="1">Low</option>
            <option value="2">Medium</option>
            <option value="3">Hight</option>
          </select>
        </td>
      </tr>
      <tr>
        <td>Tanggal</td>
        <td>:</td>
        <td><input type="date" name="tanggal" id=""></td>
      </tr>
      <tr>
        <td><input type="submit" value="Simpan"></td>
      </tr>
    </table>

  </form>
</body>

</html>