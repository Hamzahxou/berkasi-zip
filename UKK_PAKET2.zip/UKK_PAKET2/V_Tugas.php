<?php
//ambil file Tugas.php
include "Tugas.php";
//inisialisasi objek
$tugas = new Tugas;
//panggil method
$tampung = $tugas->tampilData();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>

<body>
  <h1>Daftar Tugas</h1>
  <a href="?url=tambahdata">Tambah Data</a>
  <table border="1">
    <thead>
      <tr>
        <td>No</td>
        <td>Task</td>
        <td>Prioriti</td>
        <td>Tanggal</td>
        <td>Status</td>
        <td colspan="2">Aksi</td>
      </tr>
    </thead>

    <tbody>
      <?php
      foreach ($tampung as $data) {

      ?>
        <tr>
          <td><?= $data['id'] ?></td>
          <td><?= $data['task'] ?></td>
          <td><?= $data['prioriti'] ?></td>
          <td><?= $data['tanggal'] ?></td>
          <td><?= $data['status'] ?></td>
          <td><a href="?url=edit&id=<?= $data['id'] ?>">Edit</a></td>
          <td><a href="?url=hapus&id=<?= $data['id'] ?>">Hapus</a></td>
        </tr>

      <?php } ?>
    </tbody>


  </table>
</body>

</html>