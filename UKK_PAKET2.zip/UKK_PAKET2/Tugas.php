<?php

class Tugas
{
  //method menampilkan data
  public function tampilData()
  {
    //ambil file config.php
    include "config.php";

    //sql select ke tabel tugas
    $sql = "SELECT * FROM tugas ORDER BY prioriti DESC";
    $data = mysqli_query($koneksi, $sql);

    //mengembalikan $data
    return $data;
  }

  //method tambah data
  public function tambahData($task, $prioriti, $tanggal, $status)
  {

    //ambil file config.php
    include "config.php";

    $sql = "INSERT INTO tugas VALUES(Null,'$task','$prioriti','$tanggal','$status')";

    $data = mysqli_query($koneksi, $sql);

    header("location: index.php");
  }

  //method hapus
  public function hapusData($id)
  {
    //ambil file config
    include "config.php";

    $sql = "DELETE FROM tugas WHERE id='$id'";
    $data = mysqli_query($koneksi, $sql);

    header("location: index.php");
  }

  //method tampilubah
  public function tampilUbah($id)
  {
    //ambil file config
    include "config.php";

    $sql = "SELECT * FROM tugas WHERE id='$id'";
    $data = mysqli_query($koneksi, $sql);
    $result = mysqli_fetch_assoc($data);
    // print_r($result);
    return $result;
  }

  //method simpan ubah
  public function simpanUbah($id, $task, $prioriti, $tanggal, $status)
  {
    //ambil file config
    include "config.php";

    $sql = "UPDATE tugas SET task='$task',prioriti='$prioriti',tanggal='$tanggal',status='$status' WHERE id='$id'";

    $data = mysqli_query($koneksi, $sql);
    header("location: index.php");
  }
}
